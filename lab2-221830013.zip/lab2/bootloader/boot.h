#ifndef BOOT_H
#define BOOT_H

struct ELFHeader {
	unsigned int   magic;//魔数，用于识别文件是否为ELF格式。
	unsigned char  elf[12];//ELF格式标识
	unsigned short type;//文件类型，例如可执行文件或者共享对象文件
	unsigned short machine;//目标机器架构，例如x86或ARM
	unsigned int   version;//ELF格式的版本
	unsigned int   entry;//程序入口的虚拟地址
	unsigned int   phoff;//程序头部表的偏移量
	unsigned int   shoff;//节头部表的偏移量
	unsigned int   flags;//与处理器相关的标志
	unsigned short ehsize;//ELF头部的大小
	unsigned short phentsize;//程序头部表中每个条目的大小
	unsigned short phnum;//程序头部表中条目的数量
	unsigned short shentsize;//节头部表中每个条目的大小
	unsigned short shnum;//节头部表中条目的数量
	unsigned short shstrndx;//节名称字符串表的索引
};



/* ELF32 Program header */
struct ProgramHeader {
	unsigned int type;//段的类型
	unsigned int off;//段在文件中的偏移量
	unsigned int vaddr;//段的虚拟地址
	unsigned int paddr;//段的物理地址（对于系统来说通常是不相关的）
	unsigned int filesz;//文件中的段大小
	unsigned int memsz;//内存中的段大小
	unsigned int flags;//与段相关的标志
	unsigned int align; //段在内存中的对齐方式。
};

typedef struct ELFHeader ELFHeader;//typedef ,discard "struct"
typedef struct ProgramHeader ProgramHeader;

void waitDisk(void);

void readSect(void *dst, int offset);

/* I/O functions */
static inline char inByte(short port) {
	char data; 
	asm volatile("in %1,%0" : "=a" (data) : "d" (port)); //read %0 from %1 .aka read data from port
	return data;
}

static inline int inLong(short port) {
	int data;
	asm volatile("in %1, %0" : "=a" (data) : "d" (port));
	return data;
}

static inline void outByte(short port, char data) {
	asm volatile("out %0,%1" : : "a" (data), "d" (port)); //write %0 to %1 .aka write data to port
}

#endif
