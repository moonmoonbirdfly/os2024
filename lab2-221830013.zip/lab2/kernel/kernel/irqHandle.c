#include "x86.h"
#include "device.h"

extern int displayRow;
extern int displayCol;

extern uint32_t keyBuffer[MAX_KEYBUFFER_SIZE];
extern int bufferHead;
extern int bufferTail;

int tail=0;

void GProtectFaultHandle(struct TrapFrame *tf);

void KeyboardHandle(struct TrapFrame *tf);

void syscallHandle(struct TrapFrame *tf);
void syscallWrite(struct TrapFrame *tf);
void syscallPrint(struct TrapFrame *tf);
void syscallRead(struct TrapFrame *tf);
void syscallGetChar(struct TrapFrame *tf);
void syscallGetStr(struct TrapFrame *tf);


void irqHandle(struct TrapFrame *tf) { // pointer tf = esp
	/*
	 * 中断处理程序
	 */
	/* Reassign segment register */
	asm volatile("movw %%ax, %%ds"::"a"(KSEL(SEG_KDATA)));

	switch(tf->irq) {
		case -1:{
			//log("empty.\n");
			break;
		}
		case 0xd:{
			log("GPF.\n");
			GProtectFaultHandle(tf);
			break;
		}
		case 0x21:{
			log("keyboard.\n");
			KeyboardHandle(tf);
			break;
		}
		case 0x80:{
			log("syscall.\n");
			syscallHandle(tf);
			break;
		}
		default:{
			log("unknown.\n");
			assert(0);
		}
	}
}

void GProtectFaultHandle(struct TrapFrame *tf){
	assert(0);
	return;
}

void KeyboardHandle(struct TrapFrame *tf){
	uint32_t code = getKeyCode();

	if(code == 0xe){ // 退格符
		//要求只能退格用户键盘输入的字符串，且最多退到当行行首
		if(displayCol>0&&displayCol>tail){
		    bufferTail--;
			displayCol--;
			uint16_t data = 0 | (0x0c << 8);
			int pos = (80*displayRow+displayCol)*2;
			asm volatile("movw %0, (%1)"::"r"(data),"r"(pos+0xb8000));
		}
	}else if(code == 0x1c){ // 回车符
		//处理回车情况
		keyBuffer[bufferTail++]='\n';
		displayRow++;
		displayCol=0;
		tail=0;
		if(displayRow==25){
			scrollScreen();
			displayRow=24;
			displayCol=0;
		}
	}else if(code < 0x81){ 
	    if((code < 0x81 && ((code > 1 && code < 0xe )||( code > 0xf && code != 0x1d && code != 0x2a && code != 0x36 && code != 0x38 && code != 0x3a && code < 0x45)))){
		    // TODO: 处理正常的字符
		    // 处理正常的字符输入情况
            // 存储字符到键盘缓冲区
            keyBuffer[bufferTail++] = code;
            // 将字符显示到屏幕上
            uint16_t data = (0x0c << 8) | getChar(code); // 默认白底黑字
            int pos = (80 * displayRow + displayCol) * 2; // 计算在显存中的位置
            asm volatile("movw %0, (%1)"::"r"(data),"r"(pos + 0xb8000)); // 更新显存中的字符
            displayCol++; // 列数增加
	    }
	}
	updateCursor(displayRow, displayCol);
	
}

void syscallHandle(struct TrapFrame *tf) {
	switch(tf->eax) { // syscall number
		case 0:
			syscallWrite(tf);
			break; // for SYS_WRITE
		case 1:
			syscallRead(tf);
			break; // for SYS_READ
		default:break;
	}
}

void syscallWrite(struct TrapFrame *tf) {
	switch(tf->ecx) { // file descriptor
		case 0:
			syscallPrint(tf);
			break; // for STD_OUT
		default:break;
	}
}

void syscallPrint(struct TrapFrame *tf) {
	int sel =  USEL(SEG_UDATA);
	char *str = (char*)tf->edx;
	int size = tf->ebx;
	int i = 0;
	int pos = 0;
	char character = 0;
	uint16_t data = 0;
	asm volatile("movw %0, %%es"::"m"(sel));
	for (i = 0; i < size; i++) {
		// TODO: 完成光标的维护和打印到显存
        asm volatile("movb %%es:(%1), %0":"=r"(character):"r"(str+i)); // 从用户空间加载字符
        if (character == '\n') { // 如果遇到换行符
            // 更新显示位置
            displayRow++;
            displayCol = 0;
            tail = 0;
            // 如果当前行已经到达屏幕底部，滚屏
            if (displayRow == 25) {
                scrollScreen();
                displayRow = 24;
            }
        } else {
            //printf("%x",character);
            data = (0x0c << 8) | character; 
            pos = (80 * displayRow + displayCol) * 2; // 计算在显存中的位置
            asm volatile("movw %0, (%1)"::"r"(data),"r"(pos + 0xb8000)); // 将字符打印到显存中
            if(displayCol<=80)displayCol++; // 列数增加
            else {
                displayCol=0;
                displayRow++;
            }
            if (displayRow == 25) {
                scrollScreen();
                displayRow = 24;
            }
        }

	}
	tail=displayCol;
	updateCursor(displayRow, displayCol);
}

void syscallRead(struct TrapFrame *tf){
	switch(tf->ecx){ //file descriptor
		case 0:
			syscallGetChar(tf);
			break; // for STD_IN
		case 1:
			syscallGetStr(tf);
			break; // for STD_STR
		default:{assert(0);break;}
	}
}
void syscallGetChar(struct TrapFrame *tf){
	// TODO: 自由实现
	log("syscall getchar.\n");
	assert(bufferTail==0);
	enableInterrupt();
	while(keyBuffer[bufferTail-1]!='\n') waitForInterrupt();
	disableInterrupt();
	tf->eax=getChar(keyBuffer[bufferTail-2]);
	
}

void syscallGetStr(struct TrapFrame *tf){
	// TODO: 自由实现
	log("syscall getstr.\n");
	int sel = USEL(SEG_UDATA); 
	char *str = (char*)tf->edx;
	int size = tf->ebx;
	int i = 0;
	char c=0;
	enableInterrupt();
	int old_bufferTail=bufferTail;
	while((bufferTail==old_bufferTail)^(keyBuffer[bufferTail-1]!='\n')){
        waitForInterrupt();
    }
	disableInterrupt();
	asm volatile("movw %0, %%es"::"m"(sel));
	int Size=size;
	for (i = 0; i < size; i++) {
		if(*(str+i)=='\n') {Size=(size>i)?i:size;break;}
		if(i==size-1) Size=size;
	}
	
	for (i = 0; i < Size; i++) {
		if(keyBuffer[old_bufferTail+i]=='\n')break;
		//log("1\n");
		c=getChar(keyBuffer[old_bufferTail+i]);
		if(c!=0)asm volatile("movb %0, %%es:(%1)"::"r"(c),"r"(str+i));
		//else asm volatile("movb %0, %%es:(%1)"::"r"(0),"r"(str+i));
	}
	asm volatile("movb $0x00, %%es:(%0)"::"r"(str+i));
}


