#include "x86.h"
#include "device.h"

#define SERIAL_PORT  0x3F8

void initSerial(void) {
	outByte(SERIAL_PORT + 1, 0x00);
	outByte(SERIAL_PORT + 3, 0x80);
	outByte(SERIAL_PORT + 0, 0x01);
	outByte(SERIAL_PORT + 1, 0x00);
	outByte(SERIAL_PORT + 3, 0x03);
	outByte(SERIAL_PORT + 2, 0xC7);
	outByte(SERIAL_PORT + 4, 0x0B);
}

static inline int serialIdle(void) {
	return (inByte(SERIAL_PORT + 5) & 0x20) != 0;
}

void putChar(char ch) {
	while (serialIdle() != TRUE);
	outByte(SERIAL_PORT, ch);
}

void putStr(char *ch){
	while(ch && (*ch) && (*ch)!='\0'){
		putChar(*ch);
		ch++;
	}
}
void putNum(int num){
    if (num == 0){
        putChar('0');
        return;
    }
    if (num < 0){
        putChar('-');
        num = -num;
    }
    int reverse = 0;
    int length = 0;
    int tempNum = num; 
    while(tempNum){
        length++;
        tempNum /= 10;
    }
    while(num){
        reverse = reverse * 10 + num % 10;
        num /= 10;
    }
    for(int i = 0; i < length; i++){
        if(reverse == 0 && i != length - 1){
            putChar('0');
        } else {
            char ch = (reverse % 10) + '0';
            putChar(ch);
            reverse /= 10;
        }
    }
}

void putHex(int num){
    if (num == 0){
        putChar('0');
        return;
    }
    if (num < 0){
        putChar('-');
        num = -num;
    }
    int size = 0;
    char buffer[8]; // 32位整数的16进制表示最多只有8位
    while(num){
        int digit = num % 16;
        // 如果数字小于10，加上'0'得到其ASCII码；如果大于等于10，加上'A'减去10得到其ASCII码
        buffer[size++] = (digit < 10) ? (digit + '0') : (digit - 10 + 'A');
        num /= 16;
    }
    // 由于我们从低位开始填充buffer，所以需要反向打印
    for(int i = size - 1; i >= 0; i--){
        putChar(buffer[i]);
    }
}

void log(const char * str){
	for(int i=0; str[i]!='\0'; i++)putChar(str[i]);
	//putChar("\n");
}
