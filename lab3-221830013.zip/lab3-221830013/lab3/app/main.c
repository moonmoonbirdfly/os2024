#include "lib.h"
#include "types.h"

int data = 0;

int uEntry(void)
{
	int ret = fork();
	int i = 10;

	if (ret == 0)
	{
		data = 2;
		while (i != 0)
		{
			i--;
			printf("ret = %d;\n",ret);
			printf("Child Process: Pong %d, %d;\n", data, i);
			sleep(128);
		}
		printf("Child dead\n");
		exit();
	}
	else if (ret != -1)
	{
		data = 1;
		
		while (i != 0)
		{
			i--;
			printf("ret = %d;\n",ret);
			printf("Father Process: Ping %d, %d;\n", data, i);
			sleep(128);
		}
		printf("Father dead\n");
		exit();
		
	}

	return 0;
}
