#include "x86.h"
#include "device.h"
#include "../../lib/types.h"
#include "../../lib/lib.h"

extern TSS tss;
extern ProcessTable pcb[MAX_PCB_NUM];//4
extern int current;

extern int displayRow;
extern int displayCol;

void GProtectFaultHandle(struct StackFrame *sf);

void syscallHandle(struct StackFrame *sf);
void syscallFork(struct StackFrame *sf);
void syscallWrite(struct StackFrame *sf);
void syscallPrint(struct StackFrame *sf);
void syscallSleep(struct StackFrame *sf);
void syscallExec(struct StackFrame *sf);
void syscallExit(struct StackFrame *sf);
void timerHandle(struct StackFrame *sf);
void irqHandle(struct StackFrame *sf)
{   // pointer sf = esp
	/* Reassign segment register */
	
	/*
	struct StackFrame {
	uint32_t gs, fs, es, ds;
	uint32_t edi, esi, ebp, xxx, ebx, edx, ecx, eax;
	uint32_t irq, error;
	uint32_t eip, cs, eflags, esp, ss;}
    */
    
	asm volatile("movw %%ax, %%ds" ::"a"(KSEL(SEG_KDATA)));
	/*XXX Save esp to stackTop */
	uint32_t tmpStackTop = pcb[current].stackTop;
	assert(pcb[current].stackTop == pcb[current].prevStackTop);
	pcb[current].prevStackTop = pcb[current].stackTop;
	pcb[current].stackTop = (uint32_t)sf;
    int temp=current;
    
    if(current!=0){
        log("----------start of irqhandle ...          ");
        putChar('0'+current);
        putChar('\n');
        //smaller                         bigger
        log("sf ");putHex((uint32_t)sf);putChar(' ');log("prev=stack ");putHex(pcb[current].prevStackTop);putChar(' ');putChar('\n');
    }
	switch (sf->irq)
	{
	case -1:
	    log("enter sf->irq = -1 ...\n");
		break;
	case 0xd:
	    log("enter GP ...");
		GProtectFaultHandle(sf);
		break;
	case 0x20:
	     if(current!=0)log("enter timer handle...\n");
		timerHandle(sf);
		break;
	case 0x80:
	    log("enter syscall ...\n");
		syscallHandle(sf);
		break;
	default:
	    log("enter default! W R O N G !...\n");
		assert(0);
	}
	/*XXX Recover stackTop */
	//putChar('0'+current);if(current!=0)putChar('\n');
	if(current!=0){
        log("----------end of irqhandle ...           ");
        putChar('0'+current);
        putChar('\n');
    }
	pcb[current].stackTop = tmpStackTop;
	return;
}

void GProtectFaultHandle(struct StackFrame *sf)
{
	assert(0);
	return;
}
void shift_proc(struct StackFrame *sf){
    log("(-)");
    int next_proc = (current + 1) % MAX_PCB_NUM;
    int temp=current;
    while (next_proc != current) {
        if (pcb[next_proc].state == STATE_RUNNABLE) {
            current = next_proc;
            break;
        }
        next_proc = (next_proc + 1) % MAX_PCB_NUM;
    }

    if (next_proc == current && pcb[current].state != STATE_RUNNABLE) {
        current = 0;
    }
    //uint32_t sp =(uint32_t)&pcb[current].regs.esi;
    //uint32_t sp =(uint32_t)&(pcb[current].timeCount);
    uint32_t sp =(uint32_t)&next_proc;
    uint32_t sp1 =(uint32_t)&temp;
    //assert(temp==current);
    putChar('0'+current);if(current!=0)putChar('\n');
    putChar('0'+temp);if(current!=0)putChar('\n');
    //log("\n");
    pcb[current].state = STATE_RUNNING;
    if(current!=0){
        //putChar('\n');
        assert(pcb[current].stackTop!=pcb[temp].stackTop);
        putHex(pcb[current].prevStackTop);putChar('\n');//bigger
        putHex(pcb[current].stackTop);putChar('\n');//smaller
        putHex(sp);putChar('\n');
        putHex(sp1);putChar('\n');
    }
    
    tss.esp0 = pcb[current].prevStackTop;
    uint32_t tmpStackTop = pcb[current].stackTop;   
    pcb[current].stackTop = pcb[current].prevStackTop;
	asm volatile("movl %0, %%esp"::"m"(tmpStackTop));
    asm volatile("popl %gs");
	asm volatile("popl %fs");
	asm volatile("popl %es");
	asm volatile("popl %ds");
	asm volatile("popal");
	asm volatile("addl $8, %esp");
	asm volatile("iret");
}
void timerHandle(struct StackFrame *sf) {
    // 遍历所有PCB，更新睡眠时间并更改状态
    for (int i = 0; i < MAX_PCB_NUM; i++) {
        if (pcb[i].state == STATE_BLOCKED && --pcb[i].sleepTime == 0) {
            pcb[i].state = STATE_RUNNABLE;
        }
    }

    if (pcb[current].state == STATE_RUNNING) {
        pcb[current].timeCount = (pcb[current].timeCount + 1);
        if (pcb[current].timeCount >= MAX_TIME_COUNT) {
            pcb[current].state = STATE_RUNNABLE;
            pcb[current].timeCount = 0;
        }
    }

    if (pcb[current].state != STATE_RUNNING) {
        shift_proc(sf);
    }
}

/**
#define SYS_WRITE 0
#define SYS_FORK 1
#define SYS_EXEC 2
#define SYS_SLEEP 3
#define SYS_EXIT 4
*/
void syscallHandle(struct StackFrame *sf)
{
	switch (sf->eax)
	{ // syscall number
	case SYS_WRITE:
		syscallWrite(sf);
		break; // for SYS_WRITE
		
	/*TODO Add Fork,Sleep... */
	
	case SYS_FORK:
		syscallFork(sf);
		break; // for SYS_FORK
	case SYS_EXEC:
		syscallExec(sf);
		break; // for SYS_EXEC
	case SYS_SLEEP:
		syscallSleep(sf);
		break; // for SYS_SLEEP
	case SYS_EXIT:
		syscallExit(sf);
		break; // for SYS_EXIT
	default:
		break;
	}
}

void syscallWrite(struct StackFrame *sf)
{
	switch (sf->ecx)
	{ // file descriptor
	case 0:
		syscallPrint(sf);
		break; // for STD_OUT
	default:
		break;
	}
}

void syscallPrint(struct StackFrame *sf)
{   

    
    log("syscallPrint...\n");
	int sel = sf->ds; // segment selector for user data, need further modification
	char *str = (char *)sf->edx;
	int size = sf->ebx;
	int i = 0;
	int pos = 0;
	char character = 0;
	uint16_t data = 0;
	asm volatile("movw %0, %%es" ::"m"(sel));
	for (i = 0; i < size; i++)
	{   
		asm volatile("movb %%es:(%1), %0" : "=r"(character) : "r"(str + i));
		if (character == '\n')
		{
			displayRow++;
			displayCol = 0;
			if (displayRow == 25)
			{
				displayRow = 24;
				displayCol = 0;
				scrollScreen();
			}
		}
		else
		{
			data = character | (0x0c << 8);
			pos = (80 * displayRow + displayCol) * 2;
			asm volatile("movw %0, (%1)" ::"r"(data), "r"(pos + 0xb8000));
			displayCol++;
			if (displayCol == 80)
			{
				displayRow++;
				displayCol = 0;
				if (displayRow == 25)
				{
					displayRow = 24;
					displayCol = 0;
					scrollScreen();
				}
			}
		}
		 //asm volatile("int $0x20"); //XXX Testing irqTimer during syscall
		 //asm volatile("int $0x20":::"memory"); //XXX Testing irqTimer during syscall
	}

	updateCursor(displayRow, displayCol);
	// take care of return value
	return;
}

// TODO syscallFork ...
void syscallFork(struct StackFrame *sf) {
    log("fork...\n");
	int pid = -1;
	for (int i = 0; i < MAX_PCB_NUM; i++){
		if (pcb[i].state == STATE_DEAD){
            pid = i;
			break;
        }
	}
	if (pid != -1)
	{
		for (int j = 0; j < 0x100000; j++) 
		{
			*(uint8_t *)(j + (pid+1)*0x100000) = *(uint8_t *)(j + (current+1)*0x100000);
		}
		log("pid= ");putHex(pid);log("\n");
		log("current= ");putHex(current);log("\n");
		pcb[pid].pid=pid;
		pcb[pid].stackTop = (uint32_t)&(pcb[pid].stackTop) -((uint32_t)&(pcb[current].stackTop) - pcb[current].stackTop);
	    log("new");putHex(pcb[pid].stackTop);putChar('\n');
		pcb[pid].prevStackTop = (uint32_t)&(pcb[pid].stackTop) -((uint32_t)&(pcb[current].stackTop) - pcb[current].prevStackTop);
		log("new");putHex(pcb[pid].prevStackTop);putChar('\n');
		log("old");putHex(pcb[current].prevStackTop);putChar('\n');
		log("old");putHex(pcb[current].prevStackTop);putChar('\n');
		pcb[pid].sleepTime=0;		
		pcb[pid].state = STATE_RUNNABLE;
		pcb[pid].timeCount = 0;
		pcb[pid].regs.edi = sf->edi;
		pcb[pid].regs.esi = sf->esi;
		pcb[pid].regs.ebp = sf->ebp;
		pcb[pid].regs.xxx = sf->xxx;
		pcb[pid].regs.ebx = sf->ebx;
		pcb[pid].regs.edx = sf->edx;
		pcb[pid].regs.ecx = sf->ecx;
		pcb[pid].regs.eax = sf->eax;
		pcb[pid].regs.irq = sf->irq;
		pcb[pid].regs.error = sf->error;
		pcb[pid].regs.eip = sf->eip;
		pcb[pid].regs.esp = sf->esp;
		pcb[pid].regs.eflags = sf->eflags;
		pcb[pid].regs.cs = USEL((1 + pid * 2));
		pcb[pid].regs.ss = USEL((2 + pid * 2));
		pcb[pid].regs.ds = USEL((2 + pid * 2));
		pcb[pid].regs.es = USEL((2 + pid * 2));
		pcb[pid].regs.fs = USEL((2 + pid * 2));
		pcb[pid].regs.gs = USEL((2 + pid * 2));
		pcb[pid].regs.eax = 0; 
		pcb[current].regs.eax = pid; 
	}
	else pcb[current].regs.eax = -1; 
	return;
}

void syscallSleep(struct StackFrame *sf){
    log("sleep...\n");
    pcb[current].sleepTime = sf->ecx;
    pcb[current].state = STATE_BLOCKED;
    int temp=current;
    shift_proc(sf);
    assert(temp==current);
    sf->eax = pcb[current].sleepTime;
    //sf->eax = sf->ecx;
    return;
}
void syscallExec(struct StackFrame *sf){
    assert(0);
    return;
}
void syscallExit(struct StackFrame *sf){
    log("exit...\n");
    pcb[current].state = STATE_DEAD;
    shift_proc(sf);
    sf->eax = 0;
    return;
}
